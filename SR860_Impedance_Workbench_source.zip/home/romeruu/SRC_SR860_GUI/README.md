# SR860 Impedance Workbench

Aplicación en Python para medir impedancia con un lock-in SRS SR860/SR865, visualizar `Re(Z)`, `C`, `|Z|` y `L` contra frecuencia, exportar gráficas en `SVG` y controlar el setup del instrumento desde una GUI.

## Funciones principales

- Diagnóstico de conexión con lectura de `*IDN?`, `FREQ?`, `SLVL?` y `SNAP? X,Y`.
- Medición única para validar cableado y respuesta antes de un barrido completo.
- Barrido de impedancia usando resistencia serie conocida.
- Vista automática para resistencias con `Re(Z)`, `Xz`, `|Z|` y fase contra frecuencia.
- Vista general con `Re(Z)`, `C`, `|Z|` y `L` contra frecuencia.
- Exportación de CSV, SVG seleccionables y sesión completa en JSON.
- Panel de configuración con scroll para pantallas pequeñas.

## Modelo matemático

La app asume un montaje de divisor serie con resistencia física conocida `Rs` y DUT. El campo `Z serie fuente/equipo` se suma internamente para modelar la impedancia serie del instrumento o fuente, de modo que `Rs` sea el valor real que se coloca en el montaje:

```text
Vdut = X + jY
Vsource = Veff * exp(-j*PHAS)
Rserie_total = Rs + Zserie_fuente
Zdut = Rserie_total * Vdut / (Vsource - Vdut)
```

`X` y `Y` vienen de `SNAP? X,Y` del SR860. La fase `PHAS` se incluye porque el instrumento rota la referencia de los detectores X/Y; si `PHAS = 0`, la ecuación se reduce al divisor serie real usado normalmente.

Desde la impedancia compleja `Z = Re(Z) + jXz`, calcula:

```text
Re(Z) = real(Z)
|Z| = abs(Z)
Cserie = -1 / (2*pi*f*Xz), sólo si Xz < 0
Lserie = Xz / (2*pi*f), sólo si Xz > 0
```

`C` y `L` son equivalentes serie derivados de la reactancia. Para una resistencia ideal deberían ser inexistentes o poco estables, porque `Xz` se acerca a cero.

Antes de medir, la app fuerza detección en fundamental (`HARM 1`) y apaga offset, ratio y expand en `X/Y/R` para que `SNAP? X,Y` sea una lectura RMS cruda del fasor de entrada.

La amplitud efectiva usa el modelo oficial de SINE OUT del SR860: salida diferencial, 50 Ω por BNC, amplitud RMS dependiente de si se usa single-ended/differential y carga High-Z/50 Ω. Referencia: manual oficial de Stanford Research Systems, `SR860m.pdf` (`https://thinksrs.com/downloads/pdfs/manuals/SR860m.pdf`).

Para el montaje típico con salida SINE OUT single-ended, deja `Z serie fuente/equipo = 50 Ω` y escribe en `Rs` sólo la resistencia externa real. Por ejemplo, si colocas `220 Ω`, escribe `220`; la app usará `270 Ω` en la ecuación.

## Estado del proyecto

- GUI principal: `barrido.py`
- Icono del proyecto: `srs-1.svg`
- Recursos para la app: `assets/srs-1.png`, `assets/srs-1.ico`
- Build para Windows: carpeta `windows/`

## Ejecución en Linux

```bash
cd ~/SRC_SR860_GUI
./run_gui.sh
```

## Build para Windows

La forma correcta es compilar el `.exe` directamente en una máquina Windows.

### Opción PowerShell

```powershell
cd SR860_Impedance_Workbench
.\windows\build_windows.ps1
```

### Opción CMD

```bat
cd SR860_Impedance_Workbench
windows\build_windows.bat
```

Al terminar, el ejecutable queda en:

```text
dist\SR860_Impedance_Workbench.exe
```

## Instalador para Windows

El repo también incluye un instalador con Inno Setup:

```text
windows/SR860_Impedance_Workbench.iss
```

Después de compilar el `.exe` con PyInstaller, genera el instalador con:

```powershell
iscc .\windows\SR860_Impedance_Workbench.iss
```

Eso produce un instalador en:

```text
dist_installer\SR860_Impedance_Workbench_Setup_v0.1.0.exe
```

## Dependencias de build para Windows

Se instalan automáticamente desde:

```text
windows/requirements-build.txt
```

## Publicación en GitHub

Flujo recomendado:

1. Inicializar el repo local.
2. Hacer el primer commit.
3. Crear el repo remoto en GitHub.
4. Subir por SSH.

Repo publicado:

```text
https://github.com/ROMERUU-dev/sr860-impedance-workbench
```

## Nota sobre conexión USBTMC en Linux

Si el instrumento aparece como `/dev/usbtmc0` pero no conecta, instala la regla `udev` incluida:

```bash
./fix_usbtmc_permissions.sh
```
